package postiventuretest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.swing.JOptionPane;
import postiventuretest.menue.Strings;

public class TFAmenue {

    public static void main(String[] args) throws IOException {
// INTs 
        int highscore = 0;
        int iLvlSelCounter = 1;
        int iLevelSelect = 0;
        int b = 0;
        int iMisspellCounter = 0;
        int iTotalMisspellCounter = 0;
        int iEasterggCounter = 0;
        int iFoundEastereggs = 0;
        int iTotalEastereggs = 4;
             
        System.out.println("b = " + b);
        
// STRINGS         
        String sGender = "t";
        String sUsername = "Number 5 Lives";
        String sLevelSelect = "MAP31";
        String sLevelRange = "(1 - 2)";
        String sEastereggTable = "MAP31";
        String sFoundEggs = "";

// MIXED i / s / b
        int iNameLength = sUsername.length();
        int iSpaceBeforeLastname = sUsername.lastIndexOf(" ");
        String sFirstname = sUsername.substring(0, iSpaceBeforeLastname);
        String sLastname = sUsername.substring(iSpaceBeforeLastname, iNameLength);
        boolean bSpellSwitch = false;
        
// INTRO 
        JOptionPane.showMessageDialog(null, Strings.mStTitleProducer());
        JOptionPane.showMessageDialog(null, Strings.mStTitleGameName());

// LEVEL Strings
        String sLVL01 = "notStarted";
        String sLVL02 = "notStarted";
        String sLVL03 = "notStarted";
        String sTutorial = "notStarted";
        String sEaster1234 = "notFound";
        String sEasterMessage = "notFound";
        String sLvlSelCountAch = "notFound";
        
// Gender       
        boolean bGenderEmpty = true;
        while (bGenderEmpty == true) {
            sGender = JOptionPane.showInputDialog(Strings.mStTitleGender(), "w");
            sGender = sGender.toLowerCase().trim();

            bGenderEmpty = sGender.isEmpty();
        }

// Username 
        boolean bUsernameEmpty = true;
        while (bUsernameEmpty == true) {

            if (sGender.equals("m")) {
                sUsername = JOptionPane.showInputDialog(Strings.mStInputNameMale(), "Roger Wilco");

            } else if (sGender.equals("w")) {
                sUsername = JOptionPane.showInputDialog(Strings.mStInputNameFemale(), "Jane Jansson");
            }
            
            else {
                sUsername = JOptionPane.showInputDialog(Strings.mStInputNameOther(), "Nummer 5 lebt");
            }

            bUsernameEmpty = sUsername.isEmpty();
        }
        sUsername = sUsername.trim();
        System.out.println(
                "sUsername = " + sUsername);
        
        

        System.out.println("sFirstname = " + sFirstname + " sLastname = " + sLastname);


// ### Beginn LEVELDATA 

        for (b = 0; b < 1000; b++) {
            
// EasterEggMessage
  if (iEasterggCounter == 3 || iTotalMisspellCounter == 9){
                       JOptionPane.showMessageDialog(null, sFirstname + " du hast schon " + iTotalMisspellCounter + "x eine ungültige Eingabe gemacht.\n"
                            + "Das muss natürlich belohnt werden " + sFirstname + " !!! ;)\n"
                            + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''\n"
                            + "Die Codes für ein paar der verfügbaren Eastereggs sind:\n" + sEastereggTable
                            + "\n\nMögst du lang und in Frieden leben."
                            + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''"
                            + "\n"
                            + "Übrigens: Du musst jetzt nur noch 3x etwas falsch eingeben um in diese Secretansicht zu gelangen."); 
                       
                       iMisspellCounter = 0;
                       iEasterggCounter = 2;
                       
                    while (sEasterMessage == "notFound"){
                        iFoundEastereggs++;
                        sFoundEggs = "| Eastereggs = " + iFoundEastereggs + " von " + iTotalEastereggs;
                        sEasterMessage = "found";
                    }
                       
            }          
            
// LEVELSELECT  
// LEVELSELECT Input             
            boolean bLVLselEmpty = true;
            while (bLVLselEmpty == true) {

                if (iLvlSelCounter == 25) {
                    JOptionPane.showMessageDialog(null, Strings.mStAchLvlSelEINS() + iLvlSelCounter + Strings.mStAchLvlSelZWEI());
                    while (sLvlSelCountAch == "notFound"){
                        iFoundEastereggs++;
                        sFoundEggs = "| Eastereggs = " + iFoundEastereggs + " von " + iTotalEastereggs;
                        sLvlSelCountAch = "found";
                    }
                }
                sLevelSelect = JOptionPane.showInputDialog("Highscore = " + highscore +  " | " +  sFoundEggs 
                        + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''\n" + sFirstname
                        + " tippe die Nummer eines Levels " + sLevelRange + " ein.\n\nTippe \"Tutorial\" für ein Tutorial und \"Exit\" zum beenden ein." 
                                + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''\n\n", "1");
                sLevelSelect = sLevelSelect.toLowerCase().replace("exit", "42").replace("x", "42").replace("tutorial", "33")
                        .replace("t", "33").replace("MAP31", "1942").trim();
                bLVLselEmpty = sLevelSelect.isEmpty();
            }
// LEVELSELECT Misspelling

            
            boolean bSpellingCorrect = sLevelSelect.matches("[0-9]*");
            //boolean bMisspelling = sLevelSelect.equals("1") || sLevelSelect.equals("2") || sLevelSelect.equals("33") || sLevelSelect.equals("42");
            // System.out.println("bMisspelling = " + bMisspelling);
            if (bSpellingCorrect == false) {
                sLevelSelect = sLevelSelect.replace(sLevelSelect, "1987654321");

                iMisspellCounter++;
                iTotalMisspellCounter++;
                bSpellSwitch = iTotalMisspellCounter > 9 && iMisspellCounter == 3;
                
                System.out.println("iMisspellCounter = " + iMisspellCounter);
                if (iMisspellCounter == 3 & iTotalMisspellCounter == 3) {
                    JOptionPane.showMessageDialog(null, sFirstname + " du hast schon 3x eine ungültige Eingabe gemacht.\n"
                            + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''\n"
                            + "Tippe die Nummer eines passenden Levels zB. \" 2 \" ein.\n"
                            + "Die verfügbaren Level sind: " + sLevelRange + "\n\n"
                            + "Tippe \"Tutorial\" für ein Tutorial und \"Exit\" zum beenden ein."
                                    + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''");
                    iMisspellCounter = 0;
                    
                    }
                else if (iTotalMisspellCounter > 5 && iTotalMisspellCounter < 7 || bSpellSwitch == true) {
                    JOptionPane.showMessageDialog(null, sFirstname + " du hast erneut 3x eine ungültige Eingabe gemacht.\n"
                            + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''\n"
                            + "Tippe die Nummer eines passenden Levels zB. \" 2 \" ein.\n"
                            + "Die verfügbaren Level sind: " + sLevelRange + "\n\n"
                            + "Tippe \"Tutorial\" für ein Tutorial und \"Exit\" zum beenden ein."
                                    + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''\n"
                                    + "Oder machst du das etwa... extra? ;)");
                    iMisspellCounter = 0;
                    bSpellSwitch = false;
                                                           
                    }
                }
// LEVELSELECT Too Long?
            int iLvlSelLength = sLevelSelect.length();
            if (iLvlSelLength > 10){
                sLevelSelect = sLevelSelect.substring(0, 10);
            }
            System.out.println("String sLevelSelect = " + sLevelSelect + "\n");

// LEVELSELECT Parse            
            iLevelSelect = Integer.parseInt(sLevelSelect);
            System.out.println("iLevelSelectLoop = " + iLevelSelect);

// LEVELSELECT Counter           
            iLvlSelCounter++;
            System.out.println("iLvlSelCounter = " + iLvlSelCounter);

// LEVEL 1 
            if (iLevelSelect == 1) {

                JOptionPane.showMessageDialog(null, "Hey das erste Level :)");
                boolean bQuery = false;

                while (bQuery == true) {

                    boolean bConclusion = true;

                    if (bConclusion == true) {

                    } else {
                    }

                }
                // LEVEL 2 

            } else if (iLevelSelect == 2) {
                JOptionPane.showMessageDialog(null, "Hey das zweite Level :)");

                // TUTORIAL 
            } else if (iLevelSelect == 33) {

                JOptionPane.showMessageDialog(null, "Willkommen zum Tutorial!\n"
                        + "Bist du bereit dich der Aufgabe zu stellen?\n");

                boolean b01Loop = true;
                boolean bLoesung = false;
                
                while (b01Loop == true) {
                    while (sLVL01 == "notStarted"){
                        highscore = highscore + 10;
                        sLVL01 = "started";                        
                    }
                    JOptionPane.showMessageDialog(null, "In diesem Puzzle Spiel geht es darum Zeichen aufzulösen.\n"
                            + "Bist du bereit dich der Aufgabe zu stellen?");
                    String bla = JOptionPane.showInputDialog("Tippe 1 ein", "0");
                    bLoesung = bla.matches("1");

                    if (bLoesung == true) {
                        
                        JOptionPane.showMessageDialog(null, "DU HAST ES ERFASST!");
                        
                        while (sLVL01 == "started"){
                        highscore = highscore + 20;
                        sLVL01 = "finished";                        
                    }
                        b01Loop = b01Loop == false;
                    } else {
                        b01Loop = b01Loop == false;
                    }
                }

                // EXIT 
            } else if (iLevelSelect == 42) {

                break;
            } else if (iLevelSelect == 1234) {
                
                iEasterggCounter = 3;
                
                while (sEaster1234 == "notFound"){
                    iFoundEastereggs++;
                    sEaster1234 = "found";
                }
            } 

            System.out.println("b ist " + b);

        }
        // #### Ende LEVELDATA 

// Script HIGHSCORELISTE 
        Path pfad = Paths.get(System.getProperty("user.home"))
                .resolve("Desktop").resolve("Highscore.txt");

        String inhalt = "";

        if (Files.exists(pfad)) {
            inhalt = new String(Files.readAllBytes(pfad));
        }

        inhalt +="\r\n" + " #<3# " + sUsername + " ### " + "Highscore= " + highscore + " ";

        Files.write(pfad, inhalt.getBytes());

// ENDMASSAGE 
        JOptionPane.showMessageDialog(null, "Danke fürs spielen :)");

    }

}
