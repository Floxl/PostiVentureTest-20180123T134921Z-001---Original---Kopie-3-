import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.swing.JOptionPane;

public class TextdateienBeschreibenUndAuslesenMitIf {
    
    public static void main(String[] args) throws IOException {
        
        Path pfad = Paths.get(System.getProperty("user.home"))
                .resolve("Desktop").resolve("daten.txt");
        
        String inhalt = "";
        
        if (Files.exists(pfad)) {
            inhalt = new String(Files.readAllBytes(pfad));
        }
        
        inhalt += JOptionPane.showInputDialog("Farbe") + "\n";
        
        Files.write(pfad, inhalt.getBytes());
        
    }

}
