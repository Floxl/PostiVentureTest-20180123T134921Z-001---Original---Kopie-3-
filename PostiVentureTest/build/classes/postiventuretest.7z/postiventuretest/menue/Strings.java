
package postiventuretest.menue;


public class Strings {
    
    // TITLESCREEN
    
    public static String mStTitleProducer() {
        String sProducer = "''''''''''''''''''''''''''''''''''''''''''''''''''''''''\nPOLYDESIGNER\npresents\n\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''";
        
                return sProducer;
    }
    
    public static String mStTitleGameName() {
        String sGameName = "''''''''''''''''''''''''''''''''''''''''''''''''''''''''\nTYPEQUEST\n\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''"
                + "\n2017\nCreative Commons\nBy MUVEX ENTERTAIMENT\nwww.Polydesigner.com\n\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''";
        
                return sGameName;
    }
    
// GENDER    
    
     public static String mStTitleGender() {
       String sTitleGender = "Bist du weiblich \"w\" oder männlich \"m\"?";
        
                return sTitleGender;
    }
// USERNAME
       
       public static String mStInputNameMale() {
       String sInputNameMale = "Gebe deinen Helden-Namen ein:";
        
                return sInputNameMale;
    }
       
        public static String mStInputNameFemale() {
       String sInputNameFemale = "Gebe deinen Heldinnen-Namen ein:";
        
                return sInputNameFemale;
    }   
    public static String mStInputNameOther() {
       String sInputNameOther = "Gebe deinen Namen ein:";
        
                return sInputNameOther;
    }   
       
       
        
// LEVELSELECTION      
    public static String mStAchLvlSelEINS() {
       String sAchLvlSelEINS = "ACHIEVEMENT UNLOCKED = ";
        
                return sAchLvlSelEINS;
    }   
    
     public static String mStAchLvlSelZWEI() {
       String sAchLvlSelZWEI = "x im Levelmenü gewesen!";
        
                return sAchLvlSelZWEI;
    }   
    
    /*
     "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''\n"
    
    "Highscore = " + highscore +  + sFirstname
                        + " tippe die Nummer eines Levels " + sLevelRange + " ein.\n\nTippe \"Tutorial\" für ein Tutorial und \"Exit\" zum beenden ein." 
                                + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''\n\n", "1"
    
                        
    sFirstname + " du hast schon 3x eine ungültige Eingabe gemacht.\n"
                            + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''\n"
                            + "Tippe die Nummer eines passenden Levels zB. \" 2 \" ein.\n"
                            + "Die verfügbaren Level sind: " + sLevelRange + "\n\n"
                            + "Tippe \"Tutorial\" für ein Tutorial und \"Exit\" zum beenden ein."
                                    + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''"                    
                        
// EASTEREGGS
                        
    sFirstname + " du hast schon 9x eine ungültige Eingabe gemacht.\n"
                            + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''\n"
                            + "Das muss natürlich belohnt werden " + sFirstname + "!!! ;)"
                            + "\n\nDie Codes für ein paar der verfügbaren Eastereggs sind: " + sEastereggTable
                                    + "Du hast " + iFoundEastereggs + " von " + iTotalEastereggs + " gefunden.\n\n"
                            + "Mögst du lang und in Frieden leben."
                            + "\n''''''''''''''''''''''''''''''''''''''''''''''''''''''''"
                            + "\n\n"
                                    + "Übrigens: Du musst jetzt nur noch 3x etwas falsch eingeben um in diese Secretansicht zu gelangen."                    
    
   
    
    */
    
    
}
